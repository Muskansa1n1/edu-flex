import { createRouter, createWebHistory } from "vue-router";

// Import your route components here
import HomePage from "../components/HomePage.vue";
import CourseList from "../components/CourseList.vue";
const routes = [
  { path: "/", component: HomePage },
  { path: "/courses", component: CourseList },
  // Add more routes for other pages if needed
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
